# GKE Cluster Module

This module creates a Google Kubernetes Engine (GKE) cluster.

## Usage

module "gke_cluster" {
  source         = "./modules/gke-cluster"
  project_id     = "your-project-id"
  cluster_name   = "my-cluster"
  location       = "us-central1-a"
  network        = "your-network-name"
  subnetwork     = "your-subnet-name"
}

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| project_id | The ID of the project in which to create the GKE cluster. | string |  | yes |
| cluster_name | The name of the GKE cluster. | string | `"test-cluster"` | no |
| location | The location (zone or region) in which to create the GKE cluster. | string | `"us-central1-a"` | no |
| initial_node_count | The initial number of nodes in the default node pool. | number | `1` | no |
| min_master_version | The minimum version of Kubernetes master. | string | `"latest"` | no |
| network | The network to use for the GKE cluster. | string |  | yes |
| subnetwork | The subnetwork to use for the GKE cluster. | string |  | yes |
| remove_default_node_pool | Whether to remove the default node pool. | bool | `true` | no |
| node_pool_preemptible | Whether the nodes in the default node pool are preemptible. | bool | `false` | no |
| node_pool_machine_type | The machine type for the nodes in the default node pool. | string | `"e2-medium"` | no |
| cluster_ipv4_cidr_block | The IP address range of the container pods in this cluster. | string | `"/14"` | no |
| services_ipv4_cidr_block | The IP address range of the services IPs in this cluster. | string | `"/20"` | no |
| master_username | The username for the cluster administrator. | string | `"admin"` | no |
| master_password | The password for the cluster administrator. | string | `"complex-password"` | no |

## Outputs

| Name | Description |
|---|---|
| cluster_name | The name of the GKE cluster. |
| cluster_id | The ID of the GKE cluster. |
| endpoint | The endpoint of the GKE cluster. |
| master_auth_cluster_ca_certificate | The cluster CA certificate. |
| kubeconfig | The kubeconfig for the GKE cluster. |