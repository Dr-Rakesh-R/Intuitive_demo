package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestExamplesEndToEnd(t *testing.T) {
	examplesDir := filepath.Join("..", "..", "examples")

	exampleDirs, err := files.FindSubdirectories(examplesDir)
	assert.NoError(t, err)

	for _, exampleDir := range exampleDirs {
		exampleName := filepath.Base(exampleDir)
		t.Run(exampleName, func(t *testing.T) {
			testExample(t, exampleDir)
		})
	}
}

func testExample(t *testing.T, exampleDir string) {
	t.Parallel()

	// Define Terraform options
	terraformOptions := &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": "your-project-id", // Replace with your project ID
			"network": "your-network-name",    // Replace with your network name
			"subnetwork": "your-subnet-name", // Replace with your subnetwork name
		},
	}

	// Generate a unique cluster name
	clusterName := generateUniqueClusterName(exampleDir)
	terraformOptions.Vars["cluster_name"] = clusterName

	// Initialize Terraform
	terraform.Init(t, terraformOptions)

	// Plan and Apply
	_, err := terraform.ApplyE(t, terraformOptions)
	assert.NoError(t, err, "Failed to apply Terraform configuration")

	// Destroy after complete
	defer terraform.Destroy(t, terraformOptions)

	// Validate outputs (example)
	output := terraform.Output(t, terraformOptions, "cluster_name")
	assert.Equal(t, clusterName, output)

	endpoint := terraform.Output(t, terraformOptions, "endpoint")
	assert.NotEmpty(t, endpoint)
}

func generateUniqueClusterName(exampleDir string) string {
	exampleName := filepath.Base(exampleDir)
	randID := strings.ToLower(terraform.UniqueId())
	return fmt.Sprintf("%s-%s", exampleName, randID)
}