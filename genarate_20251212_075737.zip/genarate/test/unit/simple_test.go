package simple

import (
	"fmt"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit"

	"github.com/stretchr/testify/assert"
)

func TestSimpleGKECluster(t *testing.T) {
	t.Parallel()

	clusterName := test.GetUniqueClusterName("simple-test")

	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/simple",
		Vars: map[string]interface{}{
			"cluster_name": clusterName,
			"project_id":   "your-project-id", // Replace with your project ID
			"network":      "your-network-name",    // Replace with your network name
			"subnetwork":   "your-subnet-name", // Replace with your subnetwork name
		},
	}

	// Destroy resource after the test
	defer terraform.Destroy(t, terraformOptions)

	// Initialize Terraform
	terraform.Init(t, terraformOptions)

	expectedOutputs := map[string]interface{}{
		"cluster_name": clusterName,
	}

	test.RunTestAndAssert(t, terraformOptions, expectedOutputs)

	// Additional assertions can be added here to validate specific resources or attributes
	// For example:
	// output := terraform.Output(t, terraformOptions, "endpoint")
	// assert.NotEmpty(t, output)
}