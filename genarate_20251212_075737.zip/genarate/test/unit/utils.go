package test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// RunTestAndAssert checks the Terraform plan, applies the changes, and validates the outputs.
func RunTestAndAssert(t *testing.T, terraformOptions *terraform.Options, expectedOutputs map[string]interface{}) {
	// Check Terraform format
	_, err := terraform.RunCommandAndGetStdOutE(t, terraformOptions, "fmt", "-check")
	assert.NoError(t, err, "Terraform code should be formatted")

	// Plan and check no changes (idempotency)
	plan := terraform.Plan(t, terraformOptions)
	assert.Contains(t, plan, "No changes.", "Plan should show no changes after apply")

	// Apply the changes
	terraform.Apply(t, terraformOptions)

	// Check the outputs
	for key, expectedValue := range expectedOutputs {
		actualValue := terraform.Output(t, terraformOptions, key)

		switch expectedValue.(type) {
		case string:
			assert.Equal(t, expectedValue, actualValue, fmt.Sprintf("Output %s should be %s", key, expectedValue))
		default:
			assert.Equal(t, fmt.Sprintf("%v", expectedValue), actualValue, fmt.Sprintf("Output %s should be %v", key, expectedValue))
		}
	}

}

func GetUniqueClusterName(prefix string) string {
	randID := strings.ToLower(terraform.UniqueId())
	return fmt.Sprintf("%s-%s", prefix, randID)
}