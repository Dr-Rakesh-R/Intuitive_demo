# Custom GKE Cluster Example

This example demonstrates creating a GKE cluster with a specific node count and machine type. This is a common use case when you need more control over the resources allocated to your cluster.

To run this example:

1.  Replace the placeholder values in `terraform.tfvars` with your actual project ID, network, and subnetwork.
2.  Run `terraform init`.
3.  Run `terraform apply`.

Author: Rakesh