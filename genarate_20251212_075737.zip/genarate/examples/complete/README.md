# Complete GKE Cluster Example

This example creates a GKE cluster with all available parameters configured.

To run this example:

1.  Replace the placeholder values in `terraform.tfvars` with your actual project ID, network, and subnetwork, and other desired configurations.
2.  Run `terraform init`.
3.  Run `terraform apply`.

Author: Rakesh