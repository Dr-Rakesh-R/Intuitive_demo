# Google Cloud Network Module

This module creates a Google Cloud VPC network.

## Usage

module "network" {
  source         = "./modules/network"
  project_id     = "your-project-id"
  network_name   = "my-network"
}

## Inputs

| Name                      | Description                                                                 | Type    | Default | Required |
| ------------------------- | --------------------------------------------------------------------------- | ------- | ------- | :------: |
| `project_id`              | The ID of the project in which to create the network.                       | string  |         |   yes    |
| `network_name`            | The name of the network to create.                                        | string  | `"default-network"` |   no     |
| `auto_create_subnetworks` | Whether to create subnets automatically in the network.                   | bool    | `true`  |   no     |
| `delete_default_routes`   | If set to true, all default routes are deleted when the network is deleted. | bool    | `false` |   no     |
| `mtu`                     | The network MTU.                                                             | number  | `null`  |   no     |
| `create_firewall`         | Whether to create a basic firewall rule allowing SSH access.              | bool    | `true`  |   no     |

## Outputs

| Name                  | Description                           |
| --------------------- | ------------------------------------- |
| `network_name`        | The name of the created network.      |
| `network_self_link`   | The self-link of the created network. |
| `network_id`          | The id of the created network.        |