package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

// GenerateTerraformOptionsForTest configures the terraform options with the required variables
func GenerateTerraformOptionsForTest(t *testing.T, exampleDir string) *terraform.Options {
	uniqueID := strings.ToLower(random.UniqueId())
	projectName := os.Getenv("GOOGLE_CLOUD_PROJECT")

	if projectName == "" {
		t.Fatal("GOOGLE_CLOUD_PROJECT environment variable must be set")
	}
	tempTestDir := fmt.Sprintf("../../test_tmp/%s", uniqueID)

	terraformOptions := &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": projectName,
		},
		EnvVars: map[string]string{
			"GOOGLE_CLOUD_PROJECT": projectName,
		},
		NoColor:         true,
		LockTimeout:     "5m",
		Upgrade:         true,
		TerraformBinary: "terraform",
		VarFiles:        []string{"terraform.tfvars"},
		TempDir:         tempTestDir,
	}

	return terraformOptions
}