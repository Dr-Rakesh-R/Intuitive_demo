package simple

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test_utils "github.com/your-repo/terraform-google-network/test/unit" // Replace with your actual module path
	"github.com/stretchr/testify/assert"
)

func TestSimpleExample(t *testing.T) {
	terraformOptions := test_utils.GenerateTerraformOptionsForTest(t, "../../examples/simple")

	// Clean up resources after the test
	defer terraform.Destroy(t, terraformOptions)

	// Run "terraform init" and "terraform apply". Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Get the network name from output
	networkName := terraform.Output(t, terraformOptions, "network_name")

	// Assert that the network name is not empty
	assert.NotEmpty(t, networkName)
}