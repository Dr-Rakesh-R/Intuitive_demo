package test

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestExamples(t *testing.T) {
	examplesDir := "../../examples"

	// Get all subdirectories of the examples directory
	exampleSubdirs, err := files.GetSubdirectories(examplesDir)
	assert.NoError(t, err)

	// Iterate over each example subdirectory
	for _, exampleSubdir := range exampleSubdirs {
		// Create a descriptive name for the test
		exampleName := filepath.Base(exampleSubdir)
		testName := fmt.Sprintf("Example_%s", exampleName)

		// Run a subtest for each example
		t.Run(testName, func(t *testing.T) {
			t.Parallel() // Run examples in parallel

			// Configure Terraform options for the current example
			uniqueID := strings.ToLower(random.UniqueId())
			projectName := os.Getenv("GOOGLE_CLOUD_PROJECT")

			if projectName == "" {
				t.Fatal("GOOGLE_CLOUD_PROJECT environment variable must be set")
			}

			tempTestDir := fmt.Sprintf("../../test_tmp/%s", uniqueID)

			terraformOptions := &terraform.Options{
				TerraformDir: exampleSubdir,
				Vars: map[string]interface{}{
					"project_id": projectName,
				},
				EnvVars: map[string]string{
					"GOOGLE_CLOUD_PROJECT": projectName,
				},
				NoColor:         true,
				LockTimeout:     "5m",
				Upgrade:         true,
				TerraformBinary: "terraform",
				VarFiles:        []string{"terraform.tfvars"},
				TempDir:         tempTestDir,
			}

			// Destroy the infrastructure at the end of the test
			defer terraform.Destroy(t, terraformOptions)

			// Run "terraform init" and "terraform apply". Fail the test if there are any errors.
			terraform.InitAndApply(t, terraformOptions)

			// Example assertions - replace with your specific validation logic
			outputValue := terraform.Output(t, terraformOptions, "network_name")
			assert.NotEmpty(t, outputValue, "The network_name output should not be empty")

			// Add more assertions here to validate the example
		})
	}
}