# Custom Network Example - Jumbo Frames

This example creates a Google Cloud network configured for jumbo frames (MTU=1500), disables automatic subnet creation, deletes default routes, and skips the SSH firewall rule.

To run this example:

1.  Replace `"your-project-id"` in `terraform.tfvars` with your actual Google Cloud project ID.
2.  Run `terraform init`.
3.  Run `terraform plan`.
4.  Run `terraform apply`.