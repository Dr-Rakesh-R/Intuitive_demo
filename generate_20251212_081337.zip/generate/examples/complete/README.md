# Complete Network Example

This example creates a Google Cloud network with all features enabled and customized.

To run this example:

1.  Replace `"your-project-id"` in `terraform.tfvars` with your actual Google Cloud project ID.
2.  Run `terraform init`.
3.  Run `terraform plan`.
4.  Run `terraform apply`.