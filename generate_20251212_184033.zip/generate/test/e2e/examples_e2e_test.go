package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	test_utils "test/unit"
)

func TestExamples(t *testing.T) {
	examplesDir := filepath.Join(test_utils.RootDir(), "examples")

	exampleDirs, err := files.FindSubdirectories(examplesDir)
	if err != nil {
		t.Fatalf("Failed to find examples subdirectories: %v", err)
	}

	for _, exampleDir := range exampleDirs {
		exampleName := filepath.Base(exampleDir)
		t.Run(exampleName, func(t *testing.T) {
			terraformOptions := test_utils.GenerateTerraformOptions(t, exampleDir)
			defer terraform.Destroy(t, terraformOptions)

			terraform.InitAndApply(t, terraformOptions)

			// Basic check to see if the apply worked
			output := terraform.Output(t, terraformOptions, "network_name")
			if output == "" {
				t.Errorf("network_name output is empty")
			} else {
				t.Logf("network_name output: %s", output)
			}
		})
	}
}