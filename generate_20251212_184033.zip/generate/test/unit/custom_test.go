package custom

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test_utils "test/unit"

	"github.com/stretchr/testify/assert"
)

func TestCustomExample(t *testing.T) {
	exampleDir := test_utils.GetExampleDir("custom")

	terraformOptions := test_utils.GenerateTerraformOptions(t, exampleDir)

	// Clean up resources at the end of the test
	defer terraform.Destroy(t, terraformOptions)

	// Run "terraform init" and "terraform apply". Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Check the outputs
	bucketName := terraform.Output(t, terraformOptions, "bucket_name")
	assert.Equal(t, "custom-bucket", bucketName)

	// Check the versioning output
	versioningEnabled := terraform.Output(t, terraformOptions, "versioning_enabled")
	assert.Equal(t, "true", versioningEnabled)

	t.Run("versioning_check", func(t *testing.T) {
		versioning := terraform.Output(t, terraformOptions, "versioning_enabled")
		assert.Equal(t, "true", versioning)
	})
}