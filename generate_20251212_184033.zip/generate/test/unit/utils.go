package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

// RootDir returns the root directory of this module
func RootDir() string {
	root, _ := os.Getwd()
	return strings.ReplaceAll(root, "/test/unit", "")
}

// GetExampleDir returns the path to the given example
func GetExampleDir(exampleName string) string {
	return fmt.Sprintf("%s/examples/%s", RootDir(), exampleName)
}

// GenerateTerraformOptions creates Terraform options with default settings for examples.
func GenerateTerraformOptions(t *testing.T, exampleDir string) *terraform.Options {
	return &terraform.Options{
		TerraformDir: exampleDir,
		VarFiles:     []string{"terraform.tfvars"},
		Vars: map[string]interface{}{
			"project_id": os.Getenv("GOOGLE_CLOUD_PROJECT"),
		},
		RetryableTerraformErrors: map[string]string{
			".*error waiting for instance to become ready.*": "GCP occasionally returns an error where resources are not ready",
		},
	}
}

// RandomResourceName returns a string suitable for naming test resources.
func RandomResourceName() string {
	return fmt.Sprintf("terratest-%s", random.UniqueId())
}