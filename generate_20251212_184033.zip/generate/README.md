# README.md

## Description

This Terraform module creates a Google Cloud VPC network.

## Usage

module "network" {
  source       = "./modules/network"
  project_id   = "your-project-id"
  network_name = "my-network"
}

## Inputs

| Name                      | Description                                                                                                                                    | Type   | Default | Required |
| ------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | ------ | ------- | :------: |
| `project_id`              | The ID of the project in which to create the network.                                                                                          | string |         |   yes    |
| `network_name`            | The name of the network.                                                                                                                       | string | `"default-network"` |    no    |
| `auto_create_subnetworks` | Whether to create subnetworks automatically.                                                                                                    | bool   | `false` |    no    |
| `delete_default_routes`   | If set to true, all default routes in the network are deleted. Defaults to `false`.                                                           | bool   | `false` |    no    |
| `mtu`                     | The network MTU. Must be a value between 1300 and 1500, inclusive. If set to null (the default), Google Cloud uses a default MTU of 1500. | number | `null`  |    no    |
| `routing_config`          | The network routing configuration. If not specified, regional routing is used.                                                                | object | `null`  |    no    |
| `create_firewall_rules`   | Whether to create firewall rules. Set to false if you're providing your own.                                                                 | bool   | `true`  |    no    |
| `firewall_rules`          | A list of firewall rules to create.                                                                                                            | list   | `[]`    |    no    |

## Outputs

| Name              | Description                  |
| ----------------- | ---------------------------- |
| `network_name`    | The name of the network.     |
| `network_self_link` | The self-link of the network. |