# Custom Network Example: Internal Network with SSH Access

This example creates a Google Cloud VPC network for internal use, disabling automatic subnet creation and configuring a firewall rule to allow SSH access from a specific internal range.

To run this example, you need to set the `project_id` variable.

terraform init
terraform plan -var-file="terraform.tfvars"
terraform apply -var-file="terraform.tfvars"