# Simple Network Example

This example creates a minimal Google Cloud VPC network.

To run this example, you need to set the `project_id` variable.

terraform init
terraform plan -var-file="terraform.tfvars"
terraform apply -var-file="terraform.tfvars"