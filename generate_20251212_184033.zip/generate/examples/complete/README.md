# Complete Network Example

This example creates a Google Cloud VPC network with all features enabled, including custom routing, firewall rules, and no auto-created subnetworks.

To run this example, you need to set the `project_id` variable.

terraform init
terraform plan -var-file="terraform.tfvars"
terraform apply -var-file="terraform.tfvars"