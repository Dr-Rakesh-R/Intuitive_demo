# Complete Project Example

This example creates a Google Cloud project with all available features enabled.

## Usage

To run this example, you need to:

1.  Set the required variables in `terraform.tfvars`.
2.  Run `terraform init`.
3.  Run `terraform apply`.

## Outputs

The example outputs the project ID and project number.