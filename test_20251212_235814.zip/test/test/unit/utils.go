package test

import (
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"testing"
)

func AssertTerraformOutputEquals(t *testing.T, terraformOptions *terraform.Options, outputName string, expectedValue string) {
	actualValue := terraform.Output(t, terraformOptions, outputName)
	assert.Equal(t, expectedValue, actualValue, "Terraform output %s should match", outputName)
}