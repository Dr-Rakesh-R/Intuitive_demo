package custom

import (
	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit"
	"testing"
)

func TestCustomExample(t *testing.T) {
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../examples/custom",
	})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	t.Run("BucketName", func(t *testing.T) {
		test.AssertTerraformOutputEquals(t, terraformOptions, "bucket_name", "custom-bucket")
	})

	// Example of resource attribute validation. Requires data source or resource import.
	//t.Run("ResourceAttribute", func(t *testing.T) {
	// 	bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
	// 	assert.NotEmpty(t, bucketURL)
	//})
}