package e2e

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestExamples(t *testing.T) {
	exampleDir := filepath.Join("..", "examples")

	// Find all subdirectories under the examples directory
	exampleSubdirs, err := files.GetDirsInDir(exampleDir, true)
	assert.NoError(t, err)

	for _, exampleSubdir := range exampleSubdirs {
		// Create a descriptive name for the test
		testName := strings.ReplaceAll(exampleSubdir, exampleDir+"/", "")
		testName = strings.ReplaceAll(testName, "/", "_")

		t.Run(testName, func(t *testing.T) {
			// Set up Terraform options
			terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
				TerraformDir: exampleSubdir,
			})

			// Initialize and apply the example
			terraform.InitAndApply(t, terraformOptions)

			// Check if outputs exist
			_, err := os.Stat(filepath.Join(exampleSubdir, "outputs.tf"))
			if err == nil {
				// Get Outputs and check if they are not empty
				projectID := terraform.Output(t, terraformOptions, "project_id")
				assert.NotEmpty(t, projectID, "project_id output should not be empty")
				projectNumber := terraform.Output(t, terraformOptions, "project_number")
				assert.NotEmpty(t, projectNumber, "project_number output should not be empty")
			} else {
				fmt.Println("No outputs.tf found")
			}

			// Destroy the example infrastructure
			defer terraform.Destroy(t, terraformOptions)
		})
	}
}