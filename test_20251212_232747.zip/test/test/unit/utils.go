package test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// Helper function to check if an error message contains a specific string
func AssertErrorContains(t *testing.T, err error, expectedError string) {
	assert.Error(t, err)
	assert.True(t, strings.Contains(err.Error(), expectedError), fmt.Sprintf("Expected error to contain '%s', but got '%s'", expectedError, err.Error()))
}

// Helper function to assert the output of Terraform matches expected value
func AssertOutputEquals(t *testing.T, terraformOptions *terraform.Options, outputName string, expectedValue string) {
	actualValue := terraform.Output(t, terraformOptions, outputName)
	assert.Equal(t, expectedValue, actualValue, fmt.Sprintf("Output %s should be %s", outputName, expectedValue))
}

// Helper function to assert that an output is not empty
func AssertOutputNotEmpty(t *testing.T, terraformOptions *terraform.Options, outputName string) {
	actualValue := terraform.Output(t, terraformOptions, outputName)
	assert.NotEmpty(t, actualValue, fmt.Sprintf("Output %s should not be empty", outputName))
}