package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestCompleteExample(t *testing.T) {
	t.Parallel()

	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/complete",
		VarFiles:     []string{"terraform.tfvars"},
	}

	// Clean up resources after the test
	defer terraform.Destroy(t, terraformOptions)

	// Initialize and apply the Terraform configuration
	terraform.InitAndApply(t, terraformOptions)

	t.Run("ProjectIDIsValid", func(t *testing.T) {
		projectID := terraform.Output(t, terraformOptions, "project_id")
		assert.NotEmpty(t, projectID)
		// Add more specific validations for project_id if needed.  For example, regex matching
	})

	t.Run("ProjectNumberIsNotEmpty", func(t *testing.T) {
		projectNumber := terraform.Output(t, terraformOptions, "project_number")
		assert.NotEmpty(t, projectNumber)
	})

	t.Run("ExampleValuesAreCorrect", func(t *testing.T) {
		AssertOutputEquals(t, terraformOptions, "project_id", "test-project-complete")
	})
}