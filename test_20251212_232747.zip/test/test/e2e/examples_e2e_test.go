package test

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

func TestExamples(t *testing.T) {
	examplesDir := filepath.Join("..", "..", "examples")

	exampleDirs, err := files.ListSubdirectories(examplesDir)
	if err != nil {
		t.Fatalf("Failed to list subdirectories of %s: %v", examplesDir, err)
	}

	for _, exampleDir := range exampleDirs {
		exampleName := filepath.Base(exampleDir)

		t.Run(exampleName, func(t *testing.T) {
			terraformOptions := &terraform.Options{
				TerraformDir: exampleDir,
				Upgrade:      true, // Ensure the latest module versions are used.
			}

			// Add retryable errors for intermittent issues
			retryableTerraformErrors := map[string]string{
				".*Timeout.*":               "Timeout during Terraform execution.",
				".*connection refused.*":   "Connection refused during Terraform execution.",
				".*unexpected EOF.*":       "Unexpected EOF during Terraform execution.",
				".*i/o timeout.*":          "I/O Timeout during Terraform execution.",
				".*TLS handshake timeout.*": "TLS Handshake Timeout during Terraform execution.",
				".*Please try again.*":     "Generic error, retrying.",
				".*try again later.*":      "Rate limited, retrying.",
			}
			terraformOptions.RetryableTerraformErrors = retryableTerraformErrors

			// Initialize and apply the Terraform configuration
			terraform.InitAndApply(t, terraformOptions)

			// Clean up resources after the test. Use a function so the defer is registered before the error check
			defer func() {
				terraform.Destroy(t, terraformOptions)
			}()

			// Check for required outputs
			projectID := terraform.Output(t, terraformOptions, "project_id")
			if projectID == "" {
				t.Errorf("project_id output is empty in example %s", exampleName)
			}

			// Additional validations can be added here.

			// Example validation.  Get expected value from terraform.tfvars
			tfvarsPath := filepath.Join(exampleDir, "terraform.tfvars")
			if _, err := os.Stat(tfvarsPath); err == nil { // Only validate if tfvars file exists

				tfvarsContent, err := os.ReadFile(tfvarsPath)
				if err != nil {
					t.Fatalf("Failed to read %s: %v", tfvarsPath, err)
				}

				// Extract expected project_id from terraform.tfvars
				expectedProjectID := ""
				for _, line := range strings.Split(string(tfvarsContent), "\n") {
					if strings.HasPrefix(line, "project_id") {
						parts := strings.SplitN(line, "=", 2)
						if len(parts) == 2 {
							expectedProjectID = strings.TrimSpace(strings.Trim(parts[1], "\"")) //Remove quotes
							break
						}
					}
				}

				if expectedProjectID != "" && projectID != expectedProjectID {
					t.Errorf("project_id output (%s) does not match expected value (%s) in example %s", projectID, expectedProjectID, exampleName)
				} else if expectedProjectID == "" {
					fmt.Println("Skipping project_id output validation as project_id is not set in terraform.tfvars")
				}
			} else {
				fmt.Println("Skipping project_id output validation as terraform.tfvars does not exist.")
			}

		})
	}
}