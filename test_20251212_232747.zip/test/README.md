# Terraform Google Cloud Project Module

This module creates a Google Cloud project.

## Usage

module "project" {
  source          = "./modules/project"
  project_id      = "your-project-id"
  project_name    = "Your Project Name"
  org_id          = "your-org-id"
  billing_account = "your-billing-account-id"
  owner_member    = "user:your-email@example.com"
}

## Inputs

| Name            | Description                               | Type   | Default               | Required |
| --------------- | ----------------------------------------- | ------ | --------------------- | :------: |
| `project_id`    | The ID of the project.                    | string |                       |   yes    |
| `project_name`  | The descriptive name of the project.    | string | `"example-project"`    |   no     |
| `org_id`        | The organization ID this project belongs to. | string |                       |   yes    |
| `billing_account` | The billing account ID to associate with the project. | string |                       |   yes    |
| `owner_member`    | The IAM member to grant project owner role to. | string | `"user:example@example.com"` |   no     |

## Outputs

| Name            | Description                         |
| --------------- | ----------------------------------- |
| `project_id`    | The ID of the created project.    |
| `project_number` | The project number.               |