# Custom Project Example

This example creates a Google Cloud project and assigns the owner role to a Google Group.

## Usage

To run this example:

terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars