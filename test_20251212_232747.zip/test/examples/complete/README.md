# Complete Project Example

This example creates a Google Cloud project with all features enabled.

## Usage

To run this example:

terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars