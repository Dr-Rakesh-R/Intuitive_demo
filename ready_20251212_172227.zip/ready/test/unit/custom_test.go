package custom

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test_utils "test/unit" // Alias to avoid naming conflict.
)

func TestCustomExample(t *testing.T) {
	t.Parallel()

	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../examples/custom",
	})

	// At the end of the test, run `terraform destroy` to clean up any resources that were created.
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	t.Run("ValidateOutputs", func(t *testing.T) {
		t.Parallel()
		test_utils.AssertStringOutputEquals(t, terraformOptions, "ready_id", "custom_value") // update the expected value if the main.tf is changed
		test_utils.AssertStringOutputEquals(t, terraformOptions, "project_id", "custom-project-with-org")
	})

	t.Run("ValidateResourceAttributes", func(t *testing.T) {
		t.Parallel()
		test_utils.AssertResourceAttributeSet(t, terraformOptions, "google_project.project", "project_id")
		test_utils.AssertResourceAttributeSet(t, terraformOptions, "null_resource.ready", "id")
	})
}