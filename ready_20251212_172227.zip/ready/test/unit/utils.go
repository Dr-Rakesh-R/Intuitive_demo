package test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// AssertStringOutputEquals asserts that a Terraform output with the given name is equal to the given expected value.
func AssertStringOutputEquals(t *testing.T, terraformOptions *terraform.Options, outputName string, expectedValue string) {
	actualValue := terraform.Output(t, terraformOptions, outputName)
	assert.Equal(t, expectedValue, actualValue, fmt.Sprintf("Output %s should be %s", outputName, expectedValue))
}

// AssertResourceAttributeSet asserts that a Terraform resource attribute with the given name is not empty.
func AssertResourceAttributeSet(t *testing.T, terraformOptions *terraform.Options, resourceAddress string, attributeName string) {
	attributeValue, err := terraform.GetResourceAttributeE(t, terraformOptions, resourceAddress, attributeName)
	assert.NoError(t, err)
	assert.NotEmpty(t, attributeValue, fmt.Sprintf("Resource %s attribute %s should be set", resourceAddress, attributeName))
}

// GenerateProjectID generates a unique project ID based on the test name
func GenerateProjectID(t *testing.T) string {
	testName := strings.ReplaceAll(t.Name(), "/", "-")
	return fmt.Sprintf("test-%s-%s", testName, strings.ToLower(RandomID()))
}

// RandomID returns a lowercase alphanumeric string of specified length.
func RandomID() string {
	const (
		letterBytes   = "abcdefghijklmnopqrstuvwxyz0123456789"
		letterIdxBits = 6                    // 6 bits to represent a letter index
		letterIdxMask = 1<<letterIdxBits - 1 // All 1-s, as many as letterIdxBits
		letterIdxMax  = 63 / letterIdxBits   // # of letter indices fitting in 63 bits
	)
	n := 8
	src := NewSource()
	b := make([]byte, n)
	// A src.Int63() generates 63 random bits, enough for letterIdxMax characters!
	for i, cache, remain := n-1, src.Int63(), letterIdxMax; i >= 0; {
		if remain == 0 {
			cache, remain = src.Int63(), letterIdxMax
		}
		if idx := int(cache & letterIdxMask); idx < len(letterBytes) {
			b[i] = letterBytes[idx]
			i--
		}
		cache >>= letterIdxBits
		remain--
	}

	return string(b)
}