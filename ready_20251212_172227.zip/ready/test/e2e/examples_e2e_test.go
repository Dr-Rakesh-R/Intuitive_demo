package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/require"
)

// TestExamples executes terraform init/plan/apply/destroy on all examples.
func TestExamples(t *testing.T) {
	examplesDir := filepath.Join("..", "examples")

	// Get all subdirectories of the examples directory
	exampleSubdirs, err := files.GetSubdirectories(examplesDir)
	require.NoError(t, err)

	// Make sure that each example directory has a main.tf file
	for _, exampleSubdir := range exampleSubdirs {
		exampleDir := filepath.Join(examplesDir, exampleSubdir)
		t.Run(exampleSubdir, func(t *testing.T) {
			// Configure Terraform options
			terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
				TerraformDir: exampleDir,
			})

			// defer the destroy command to cleanup resources
			defer terraform.Destroy(t, terraformOptions)

			// Run terraform init and apply
			terraform.InitAndApply(t, terraformOptions)

			// Optionally add assertions here to validate the resources created
			// Example: Check if a certain output exists
			outputValue := terraform.Output(t, terraformOptions, "project_id")
			require.NotEmpty(t, outputValue, "project_id output should not be empty")
		})
	}
}

// NewSource returns a source of random numbers
func NewSource() *lockedSource {
	seed := computeSeed()
	return &lockedSource{
		seed: seed,
		rnd:  newLockedRand(seed),
	}
}

// computeSeed returns an int64 that is based on the environment
func computeSeed() int64 {
	environmentSeed := os.Getenv("RANDOM_SEED")
	if environmentSeed != "" {
		var seed int64
		_, err := fmt.Sscan(environmentSeed, &seed)
		if err == nil {
			return seed
		}
	}
	return getSeed()
}

// getSeed returns a seed for the random number generator
// Note that the seed *must* be the same on every machine, or the test will fail.
func getSeed() int64 {
	return int64(42)
}

// A lockedSource is a source of random numbers that is safe for concurrent use.
type lockedSource struct {
	seed int64
	rnd  *lockedRand
}

// Int63 returns a non-negative pseudo-random 63-bit integer as an int64 from the default shared source.
func (r *lockedSource) Int63() int64 {
	return r.rnd.Int63()
}

// Seed uses the provided seed value to initialize the generator to a deterministic state.
// If Seed is not called, the generator behaves as if seeded by Seed(1).
// Seed values that have the same absolute value are equivalent.
func (r *lockedSource) Seed(seed int64) {
	r.seed = seed
	r.rnd.Seed(seed)
}

// A lockedRand is a thread-safe random number generator.
type lockedRand struct {
	number int64
}

// newLockedRand returns a new locked rand
func newLockedRand(seed int64) *lockedRand {
	return &lockedRand{
		number: seed,
	}
}

// Int63 returns a non-negative pseudo-random 63-bit integer as an int64 from the default shared source.
func (r *lockedRand) Int63() int64 {
	r.number = (r.number*1103515245 + 12345) & 0x7fffffffffffffff
	return r.number
}

// Seed uses the provided seed value to initialize the generator to a deterministic state.
// If Seed is not called, the generator behaves as if seeded by Seed(1).
// Seed values that have the same absolute value are equivalent.
func (r *lockedRand) Seed(seed int64) {
	r.number = seed
}

// String returns a lowercase alphanumeric string of specified length.
func String(n int) string {
	const (
		letterBytes   = "abcdefghijklmnopqrstuvwxyz0123456789"
		letterIdxBits = 6                    // 6 bits to represent a letter index
		letterIdxMask = 1<<letterIdxBits - 1 // All 1-s, as many as letterIdxBits
		letterIdxMax  = 63 / letterIdxBits   // # of letter indices fitting in 63 bits
	)
	sb := strings.Builder{}
	sb.Grow(n)
	src := NewSource()
	// A src.Int63() generates 63 random bits, enough for letterIdxMax characters!
	for i, cache, remain := n-1, src.Int63(), letterIdxMax; i >= 0; {
		if remain == 0 {
			cache, remain = src.Int63(), letterIdxMax
		}
		if idx := int(cache & letterIdxMask); idx < len(letterBytes) {
			sb.WriteByte(letterBytes[idx])
			i--
		}
		cache >>= letterIdxBits
		remain--
	}
	return sb.String()
}