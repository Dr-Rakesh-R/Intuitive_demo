# README.md
# Documentation for the "ready" module.

## Usage

module "ready" {
  source = "./modules/ready"

  input_string = "example_value"
  project_name = "my-project-name"
  project_id   = "my-project-id"
  org_id       = "1234567890"
  billing_account_id = "000000-000000-000000"
}

## Inputs

| Name             | Description                      | Type   | Default         | Required |
| ---------------- | -------------------------------- | ------ | --------------- | -------- |
| `input_string`   | A string input variable.          | string | `"default_value"` | no       |
| `project_name`   | The display name of the project. | string | n/a             | yes      |
| `project_id`     | The unique ID of the project.    | string | n/a             | yes      |
| `org_id`         | The organization ID.             | string | `""`            | no       |
| `billing_account_id`| The billing account ID        | string | n/a             | yes       |

## Outputs

| Name       | Description                            |
| ---------- | -------------------------------------- |
| `ready_id` | The ID of the null resource.           |
| `project_id` | The project ID of the created project.|