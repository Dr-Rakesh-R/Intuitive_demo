# Simple Example

This example demonstrates the minimal configuration required to use the `ready` module.