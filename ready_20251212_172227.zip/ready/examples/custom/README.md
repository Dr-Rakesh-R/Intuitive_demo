# Custom Example: Project with Organization

This example shows how to create a project associated with an organization using the `ready` module.  The `org_id` variable is set, demonstrating its usage.