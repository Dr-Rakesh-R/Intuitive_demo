# Archive Storage Bucket Example

This example demonstrates how to configure a Google Cloud Storage bucket for long-term archive storage.
It sets the storage class to `ARCHIVE`, enables versioning, and sets a lifecycle rule to delete objects older than 365 days (1 year).

To run this example:

1.  Ensure you have Terraform installed.
2.  Configure your Google Cloud credentials.
3.  Run `terraform init`.
4.  Run `terraform plan`.
5.  Run `terraform apply`.

Replace `"archive-bucket-example"` with a globally unique bucket name.