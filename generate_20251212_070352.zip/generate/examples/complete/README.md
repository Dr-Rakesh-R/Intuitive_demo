# Complete Bucket Example

This example demonstrates a comprehensive configuration of the Google Cloud Storage bucket module, enabling all features.

To run this example:

1.  Ensure you have Terraform installed.
2.  Configure your Google Cloud credentials.
3.  Run `terraform init`.
4.  Run `terraform plan`.
5.  Run `terraform apply`.

Replace `"complete-bucket-example"` with a globally unique bucket name.