# Simple Bucket Example

This example demonstrates the minimal configuration required to create a Google Cloud Storage bucket using the module.

To run this example:

1.  Ensure you have Terraform installed.
2.  Configure your Google Cloud credentials.
3.  Run `terraform init`.
4.  Run `terraform plan`.
5.  Run `terraform apply`.

Replace `"simple-bucket-example"` with a globally unique bucket name.