package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestExamples(t *testing.T) {
	examplesDir := filepath.Join("..", "examples")

	exampleDirs, err := files.FindDirsInDir(examplesDir, []string{}, []string{}, false)
	assert.NoError(t, err)

	for _, exampleDir := range exampleDirs {
		exampleName := filepath.Base(exampleDir)

		t.Run(exampleName, func(t *testing.T) {
			t.Parallel()

			// Generate unique bucket name
			uniqueBucketName := fmt.Sprintf("%s-%s", exampleName, strings.ToLower(os.Getenv("TF_VAR_project_id")))

			terraformOptions := &terraform.Options{
				TerraformDir: exampleDir,
				Vars: map[string]interface{}{ // Override bucket_name to be unique
					"bucket_name": uniqueBucketName,
				},
			}

			defer terraform.Destroy(t, terraformOptions)

			terraform.InitAndApply(t, terraformOptions)

			// Basic validation: check bucket exists
			bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
			assert.NotEmpty(t, bucketURL)
			assert.Contains(t, bucketURL, uniqueBucketName)

		})
	}
}