package complete

import (
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit" // Import the test utils package
	"github.com/stretchr/testify/assert"
)

func TestCompleteExample(t *testing.T) {
	t.Parallel()

	bucketName := test.GenerateUniqueBucketName("complete-test")
	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/complete",
		Vars: map[string]interface{}{
			"bucket_name":                 bucketName,
			"bucket_location":             "US",
			"bucket_storage_class":        "NEARLINE",
			"force_destroy":               true,
			"uniform_bucket_level_access": false,
			"versioning_enabled":          true,
			"lifecycle_rule_age":          60,
		},
	}

	defer terraform.Destroy(t, terraformOptions)

	test.InitAndApply(t, terraformOptions)

	t.Run("BucketExists", func(t *testing.T) {
		_, err := terraform.GetBucket(t, "complete-test", bucketName)
		assert.NoError(t, err)
	})

	t.Run("ValidateBucketAttributes", func(t *testing.T) {
		bucketID := terraform.Output(t, terraformOptions, "bucket_id")
		assert.Equal(t, bucketName, strings.ReplaceAll(bucketID, "gs://", ""))

		bucketNameOutput := terraform.Output(t, terraformOptions, "bucket_name")
		assert.Equal(t, bucketName, bucketNameOutput)

		bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
		assert.Equal(t, "gs://"+bucketName, bucketURL)

	})

	t.Run("VersioningEnabled", func(t *testing.T) {
		versioning := terraform.Output(t, terraformOptions, "bucket_self_link")
		assert.NotEmpty(t, versioning) // Dummy check that at least it exists - replace with actual versioning check when possible with terratest
	})

}