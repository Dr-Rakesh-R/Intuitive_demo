package simple

import (
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit"
	"github.com/stretchr/testify/assert"
)

func TestSimpleExample(t *testing.T) {
	t.Parallel()

	bucketName := test.GenerateUniqueBucketName("simple-test")

	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/simple",
		Vars: map[string]interface{}{
			"bucket_name": bucketName,
		},
	}

	defer terraform.Destroy(t, terraformOptions)

	test.InitAndApply(t, terraformOptions)

	t.Run("BucketExists", func(t *testing.T) {
		_, err := terraform.GetBucket(t, "simple-test", bucketName)
		assert.NoError(t, err)
	})

	t.Run("ValidateBucketAttributes", func(t *testing.T) {
		bucketID := terraform.Output(t, terraformOptions, "bucket_id")
		assert.Equal(t, bucketName, strings.ReplaceAll(bucketID, "gs://", ""))

		bucketNameOutput := terraform.Output(t, terraformOptions, "bucket_name")
		assert.Equal(t, bucketName, bucketNameOutput)

		bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
		assert.Equal(t, "gs://"+bucketName, bucketURL)

	})
}