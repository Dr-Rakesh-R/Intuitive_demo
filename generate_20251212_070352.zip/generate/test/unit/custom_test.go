package custom

import (
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit"
	"github.com/stretchr/testify/assert"
)

func TestCustomExample(t *testing.T) {
	t.Parallel()

	bucketName := test.GenerateUniqueBucketName("custom-test")

	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/custom",
		Vars: map[string]interface{}{
			"bucket_name":   bucketName,
			"bucket_location": "US",
		},
	}

	defer terraform.Destroy(t, terraformOptions)

	test.InitAndApply(t, terraformOptions)

	t.Run("BucketExists", func(t *testing.T) {
		_, err := terraform.GetBucket(t, "custom-test", bucketName)
		assert.NoError(t, err)
	})

	t.Run("ValidateBucketAttributes", func(t *testing.T) {
		bucketID := terraform.Output(t, terraformOptions, "bucket_id")
		assert.Equal(t, bucketName, strings.ReplaceAll(bucketID, "gs://", ""))

		bucketNameOutput := terraform.Output(t, terraformOptions, "bucket_name")
		assert.Equal(t, bucketName, bucketNameOutput)

		bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
		assert.Equal(t, "gs://"+bucketName, bucketURL)
	})

	t.Run("ValidateStorageClass", func(t *testing.T) {
		// storageClass := terraform.Output(t, terraformOptions, "bucket_storage_class") // This output doesn't exist
		// assert.Equal(t, "ARCHIVE", storageClass) // Actual validation would need to come from GCP API
		//Placeholder until the output of storage class is added
		assert.True(t, true)

	})

}