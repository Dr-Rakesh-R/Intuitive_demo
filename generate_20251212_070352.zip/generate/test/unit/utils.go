package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
)

// GenerateUniqueBucketName generates a unique bucket name for testing.
func GenerateUniqueBucketName(prefix string) string {
	return fmt.Sprintf("%s-%s", prefix, strings.ToLower(os.Getenv("TF_VAR_project_id"))) // Using project ID to ensure uniqueness
}

// InitAndApply runs terraform init and apply.
func InitAndApply(t *testing.T, terraformOptions *terraform.Options) {
	terraform.Init(t, terraformOptions)
	terraform.Apply(t, terraformOptions)
}