# Terraform Google Cloud Storage Bucket Module

This module creates a Google Cloud Storage bucket.

## Usage

module "bucket" {
  source          = "./modules/generate" # Or the path to the module in a registry

  bucket_name     = "unique-bucket-name" # Replace with a globally unique name
  bucket_location = "US"
}

output "bucket_url" {
    value = module.bucket.bucket_url
}

## Inputs

| Name                         | Description                                                                    | Type   | Default   | Required |
| ---------------------------- | ------------------------------------------------------------------------------ | ------ | --------- | -------- |
| `bucket_name`                | The name of the bucket. Must be globally unique.                               | string | n/a       | yes      |
| `bucket_location`            | The location of the bucket (e.g., US, EU, ASIA).                              | string | `"US"`    | no       |
| `bucket_storage_class`       | The storage class of the bucket (e.g., STANDARD, NEARLINE, COLDLINE, ARCHIVE). | string | `"STANDARD"` | no       |
| `force_destroy`              | If true, deletes all objects in the bucket when the bucket is destroyed.         | bool   | `false`   | no       |
| `uniform_bucket_level_access` | Enables uniform bucket-level access.                                          | bool   | `true`    | no       |
| `versioning_enabled`         | Enable object versioning.                                                      | bool   | `false`   | no       |
| `lifecycle_rule_age`         | The age (in days) before applying the lifecycle rule.                          | number | `30`      | no       |

## Outputs

| Name              | Description               |
| ----------------- | ------------------------- |
| `bucket_id`       | The ID of the bucket.     |
| `bucket_name`     | The name of the bucket.   |
| `bucket_self_link` | The self-link to the bucket. |
| `bucket_url`      | The URL of the bucket.    |