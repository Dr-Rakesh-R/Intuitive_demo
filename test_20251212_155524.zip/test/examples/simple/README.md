# Simple Project Example

This example demonstrates a minimal configuration for creating a Google Cloud Project.