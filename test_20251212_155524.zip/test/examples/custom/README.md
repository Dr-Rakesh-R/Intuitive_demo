# Development Project Example

This example shows a specific use case for creating a development environment project, with a dedicated DevOps user granted viewer permissions.