# Complete Project Example

This example demonstrates a complete configuration, enabling all features of the module.