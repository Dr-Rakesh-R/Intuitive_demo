package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestCustom(t *testing.T) {
	terraformDir := "../../examples/custom"

	extraOptions := map[string]interface{}{
		"project_name": "custom-project",
	}

	terraformOptions := GenerateTerraformOptions(t, terraformDir, extraOptions)

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	projectID := terraform.Output(t, terraformOptions, "project_id")
	projectName := terraform.Output(t, terraformOptions, "project_name")

	AssertProjectIDValid(t, projectID)

	t.Run("ProjectIDNotEmpty", func(t *testing.T) {
		assert.NotEmpty(t, projectID)
	})

	t.Run("ProjectNameMatches", func(t *testing.T) {
		assert.Equal(t, "development-project", projectName)
	})
}