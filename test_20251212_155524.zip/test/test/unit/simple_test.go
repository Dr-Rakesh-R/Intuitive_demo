package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestSimple(t *testing.T) {
	terraformDir := "../../examples/simple"

	terraformOptions := GenerateTerraformOptions(t, terraformDir, map[string]interface{}{})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	projectID := terraform.Output(t, terraformOptions, "project_id")
	projectName := terraform.Output(t, terraformOptions, "project_name")

	AssertProjectIDValid(t, projectID)

	t.Run("ProjectIDNotEmpty", func(t *testing.T) {
		assert.NotEmpty(t, projectID)
	})

	t.Run("ProjectNameNotEmpty", func(t *testing.T) {
		assert.NotEmpty(t, projectName)
	})
}