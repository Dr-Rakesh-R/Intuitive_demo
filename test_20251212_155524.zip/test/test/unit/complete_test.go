package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestComplete(t *testing.T) {
	terraformDir := "../../examples/complete"

	extraOptions := map[string]interface{}{
		"project_name": "test-project",
	}

	terraformOptions := GenerateTerraformOptions(t, terraformDir, extraOptions)

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	projectID := terraform.Output(t, terraformOptions, "project_id")
	projectName := terraform.Output(t, terraformOptions, "project_name")

	AssertProjectIDValid(t, projectID)

	t.Run("ProjectIDNotEmpty", func(t *testing.T) {
		assert.NotEmpty(t, projectID)
	})

	t.Run("ProjectNameMatches", func(t *testing.T) {
		assert.Equal(t, "my-complete-project", projectName)
	})
}