package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

// GenerateTerraformOptions creates Terraform options with a unique project ID
func GenerateTerraformOptions(t *testing.T, terraformDir string, extraOptions map[string]interface{}) *terraform.Options {
	uniqueID := strings.ToLower(random.UniqueId())
	projectId := fmt.Sprintf("terratest-%s", uniqueID)

	// Check if a project_id is already provided in extraOptions
	if _, ok := extraOptions["project_id"]; ok {
		projectId = extraOptions["project_id"].(string)
	}

	defaultOptions := map[string]interface{}{
		"project_id": projectId,
	}

	// Merge defaultOptions with extraOptions, giving precedence to extraOptions
	for key, value := range defaultOptions {
		if _, ok := extraOptions[key]; !ok {
			extraOptions[key] = value
		}
	}

	// Set required environment variables
	os.Setenv("GOOGLE_CLOUD_PROJECT", projectId)

	return &terraform.Options{
		TerraformDir: terraformDir,
		Vars:         extraOptions,
		BackendConfig: map[string]interface{}{
			"bucket": "gcp-terraform-state-" + uniqueID, // Replace with your state bucket, make unique
		},
	}
}

// AssertProjectIDValid checks if the project ID is valid
func AssertProjectIDValid(t *testing.T, projectID string) {
	if projectID == "" {
		t.Fatal("Project ID is empty")
	}
	if !strings.Contains(projectID, "terratest") {
		t.Log("Project ID does not contain terratest")
	}
}