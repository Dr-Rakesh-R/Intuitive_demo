package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestExamples(t *testing.T) {
	examplesDir := filepath.Join("..", "..", "examples")

	exampleDirs, err := files.FindSubdirectories(examplesDir)
	if err != nil {
		t.Fatalf("Failed to find subdirectories in %s: %v", examplesDir, err)
	}

	for _, exampleDir := range exampleDirs {
		exampleName := filepath.Base(exampleDir)

		t.Run(exampleName, func(t *testing.T) {
			t.Parallel()

			testExample(t, exampleDir)
		})
	}
}

func testExample(t *testing.T, exampleDir string) {
	// Create a unique ID for the project to ensure uniqueness.
	uniqueID := strings.ToLower(random.UniqueId())
	projectId := fmt.Sprintf("terratest-%s", uniqueID)

	// Set required environment variables
	os.Setenv("GOOGLE_CLOUD_PROJECT", projectId)

	// Define variables
	test_structure.SaveString(t, exampleDir, "project_id", projectId)
	test_structure.SaveString(t, exampleDir, "location", "us-central1")

	terraformOptions := &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": projectId,
		},
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created.
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	// Optionally, you can verify outputs or resource attributes here.
	// Example:
	// outputValue := terraform.Output(t, terraformOptions, "example_output")
	// assert.Equal(t, "expected_value", outputValue)
}