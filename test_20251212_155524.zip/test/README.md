# README.md
# Documentation for the test module

This module creates a Google Cloud Project.

## Usage

module "test" {
  source = "./modules/test"

  project_id         = "your-project-id"
  project_name       = "your-project-name"
  org_id             = "your-org-id"
  billing_account_id = "your-billing-account-id"
  test_user_email   = "user@example.com"
}

## Inputs

| Name                | Description                               | Type   | Default        | Required |
|---------------------|-------------------------------------------|--------|----------------|----------|
| `project_id`        | The ID of the project                     | string |                | yes      |
| `project_name`      | The name of the project                   | string | `"test-project"` | no       |
| `org_id`            | The ID of the organization                | string |                | yes      |
| `billing_account_id`| The ID of the billing account             | string |                | yes      |
| `test_user_email`   | Email to grant project viewer role | string | "test@example.com"    | no      |

## Outputs

| Name         | Description           |
|--------------|-----------------------|
| `project_id` | The ID of the project |
| `project_name`| The name of the project |