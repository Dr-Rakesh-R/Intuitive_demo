# Simple VPC Example

This example demonstrates the minimal configuration required to create a VPC network.