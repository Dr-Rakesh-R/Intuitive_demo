# Shared VPC Host Network Example

This example demonstrates creating a VPC network for use as a Shared VPC host.  It disables auto-create subnetworks and does not create any subnetworks, as these are typically handled by the service projects.