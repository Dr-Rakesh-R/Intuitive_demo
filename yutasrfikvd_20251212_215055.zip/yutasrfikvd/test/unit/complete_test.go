package complete

import (
	"testing"

	test "test/unit"

	"github.com/stretchr/testify/assert"
)

func TestCompleteVPC(t *testing.T) {
	exampleDir := "../../examples/complete"

	test.RunTerraformTest(t, exampleDir, func(t *testing.T, terraformOptions *test.TerraformOptions) {
		t.Run("NetworkName", func(t *testing.T) {
			test.AssertStringOutputE(t, terraformOptions, "network_name", "complete-network")
		})

		t.Run("SubnetName", func(t *testing.T) {
			test.AssertStringOutputE(t, terraformOptions, "subnet_name", "complete-network-subnet")
		})

		t.Run("NetworkIDIsSet", func(t *testing.T) {
			test.AssertResourceAttributeSetE(t, terraformOptions, "google_compute_network.network", "id")
		})

		t.Run("SubnetIDIsSet", func(t *testing.T) {
			test.AssertResourceAttributeSetE(t, terraformOptions, "google_compute_subnetwork.subnet[0]", "id")
		})

		t.Run("CheckSubnetCIDR", func(t *testing.T) {
			subnetID := terraformOptions.Vars["subnet_ip_cidr_range"]
			assert.Equal(t, "10.1.0.0/16", subnetID, "Should match expected subnet CIDR")
		})
	})
}