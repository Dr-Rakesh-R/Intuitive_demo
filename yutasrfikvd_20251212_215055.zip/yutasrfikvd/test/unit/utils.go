package test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// AssertStringOutputE function to assert string output from terraform
func AssertStringOutputE(t *testing.T, terraformOptions *terraform.Options, outputName string, expected string) {
	actual := terraform.Output(t, terraformOptions, outputName)
	assert.Equal(t, expected, actual, fmt.Sprintf("Output %s should be %s", outputName, expected))
}

// AssertResourceAttributeSetE function to assert that a resource attribute is set in terraform
func AssertResourceAttributeSetE(t *testing.T, terraformOptions *terraform.Options, resourceAddress string, attributeName string) {
	attributeValue := terraform.Output(t, terraformOptions, attributeName)
	assert.NotEmpty(t, attributeValue, fmt.Sprintf("Attribute %s for resource %s should be set", attributeName, resourceAddress))
}

func GetTerraformOptions(t *testing.T, exampleDir string) *terraform.Options {
	return &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": "your-project-id", // Replace with a valid project ID for testing
		},
	}
}

func RunTerraformTest(t *testing.T, exampleDir string, assertions func(t *testing.T, terraformOptions *terraform.Options)) {
	terraformOptions := GetTerraformOptions(t, exampleDir)

	// Defer the destroy command so it is always executed at the end of the test
	defer terraform.Destroy(t, terraformOptions)

	// Initialize and apply the infrastructure
	terraform.InitAndApply(t, terraformOptions)

	assertions(t, terraformOptions)
}

// Convert a string to a format that is valid as a Terraform name.
func TerraformName(t *testing.T, str string) string {
	out := strings.ReplaceAll(str, " ", "-")
	out = strings.ReplaceAll(out, "_", "-")
	out = strings.ToLower(out)

	return out
}