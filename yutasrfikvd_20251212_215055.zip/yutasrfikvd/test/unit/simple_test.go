package simple

import (
	"testing"

	test "test/unit"
)

func TestSimpleVPC(t *testing.T) {
	exampleDir := "../../examples/simple"

	test.RunTerraformTest(t, exampleDir, func(t *testing.T, terraformOptions *test.TerraformOptions) {
		t.Run("NetworkName", func(t *testing.T) {
			test.AssertStringOutputE(t, terraformOptions, "network_name", "default-network")
		})

		t.Run("NetworkIDIsSet", func(t *testing.T) {
			test.AssertResourceAttributeSetE(t, terraformOptions, "google_compute_network.network", "id")
		})
	})
}