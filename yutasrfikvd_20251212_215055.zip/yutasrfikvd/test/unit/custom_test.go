package custom

import (
	"testing"

	test "test/unit"
)

func TestCustomVPC(t *testing.T) {
	exampleDir := "../../examples/custom"

	test.RunTerraformTest(t, exampleDir, func(t *testing.T, terraformOptions *test.TerraformOptions) {
		t.Run("NetworkName", func(t *testing.T) {
			test.AssertStringOutputE(t, terraformOptions, "network_name", "shared-vpc-network")
		})

		t.Run("NetworkIDIsSet", func(t *testing.T) {
			test.AssertResourceAttributeSetE(t, terraformOptions, "google_compute_network.network", "id")
		})
	})
}