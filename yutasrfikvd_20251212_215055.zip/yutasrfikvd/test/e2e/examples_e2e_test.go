package e2e

import (
	"fmt"
	"io/ioutil"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestExamples(t *testing.T) {
	exampleDir := "../../examples"

	// Discover all example directories
	exampleDirs, err := ioutil.ReadDir(exampleDir)
	if err != nil {
		t.Fatalf("Failed to read example directory: %v", err)
	}

	for _, dir := range exampleDirs {
		if dir.IsDir() {
			exampleName := dir.Name()
			t.Run(exampleName, func(t *testing.T) {
				testExample(t, filepath.Join(exampleDir, exampleName))
			})
		}
	}
}

func testExample(t *testing.T, examplePath string) {
	terraformOptions := &terraform.Options{
		TerraformDir: examplePath,
		Vars: map[string]interface{}{
			"project_id": "your-project-id", // Replace with your actual project ID for e2e tests
		},
	}

	// Defer the destroy command so it is always executed at the end of the test
	defer terraform.Destroy(t, terraformOptions)

	// Initialize and apply the infrastructure
	terraform.InitAndApply(t, terraformOptions)

	// Basic validation - check that network_name output is not empty
	networkName := terraform.Output(t, terraformOptions, "network_name")
	assert.NotEmpty(t, networkName, "network_name output should not be empty")

	// Optionally, add more specific validation based on the example
	if strings.Contains(examplePath, "complete") {
		subnetName := terraform.Output(t, terraformOptions, "subnet_name")
		assert.NotEmpty(t, subnetName, "subnet_name output should not be empty in complete example")
	}
}