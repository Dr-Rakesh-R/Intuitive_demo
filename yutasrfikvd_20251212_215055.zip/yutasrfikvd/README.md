# Google Cloud VPC Network Module

This module creates a Google Cloud VPC network and an optional subnetwork. It follows Google Cloud best practices for networking.

## Usage

module "vpc" {
  source         = "./modules/vpc" # Replace with the actual path to your module

  project_id               = "your-project-id"
  network_name             = "my-custom-network"
  auto_create_subnetworks = false

  routing_config = {
    routing_mode = "GLOBAL"
  }

  create_subnet = true
  subnet_ip_cidr_range = "10.0.0.0/24"
  region = "us-west1"
}

## Inputs

| Name                       | Description                                  | Type   | Default  | Required |
| -------------------------- | -------------------------------------------- | ------ | -------- | -------- |
| `network_name`             | The name of the VPC network.                 | string | `"default-network"` | no       |
| `auto_create_subnetworks` | Whether to create subnetworks automatically. | bool   | `false`  | no       |
| `project_id`               | The ID of the project.                       | string | n/a      | yes      |
| `routing_config`           | The routing configuration for the network. | object | `null` | no |
| `create_subnet` | Whether to create a subnetwork. | bool   | `false`  | no       |
| `subnet_ip_cidr_range` | The IP CIDR range for the subnetwork. | string | `"10.10.0.0/24"`  | no       |
| `region` | The region for the subnetwork. | string | `"us-central1"`  | no       |

## Outputs

| Name                | Description                                    |
| ------------------- | ---------------------------------------------- |
| `network_name`      | The name of the VPC network.                   |
| `network_id`        | The ID of the VPC network.                     |
| `network_self_link` | The self-link of the VPC network.              |
| `subnet_name`       | The name of the subnetwork. |
| `subnet_id`         | The ID of the subnetwork. |