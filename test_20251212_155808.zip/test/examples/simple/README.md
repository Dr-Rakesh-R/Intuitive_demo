# Simple Network Example

This example creates a basic Google Cloud VPC network with default settings.

To run this example, you need to replace `"your-project-id"` in `terraform.tfvars` with your actual Google Cloud project ID.

Then, run:

terraform init
terraform plan
terraform apply