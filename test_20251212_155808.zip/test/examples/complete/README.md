# Complete Network Example

This example creates a Google Cloud VPC network with all features enabled, including a custom network name, automatic subnetwork creation, and global routing mode.

To run this example, you need to replace `"your-project-id"` in `terraform.tfvars` with your actual Google Cloud project ID.

Then, run:

terraform init
terraform plan
terraform apply