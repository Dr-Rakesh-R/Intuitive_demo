# Custom Network Example

This example creates a Google Cloud VPC network named "my-custom-vpc" with auto_create_subnetworks disabled. This configuration pattern is useful when you want full control over subnet creation and IP address ranges.

To run this example, you need to replace `"your-project-id"` in `terraform.tfvars` with your actual Google Cloud project ID.

Then, run:

terraform init
terraform plan
terraform apply