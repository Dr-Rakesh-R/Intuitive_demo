package test

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestExamples(t *testing.T) {
	examplesDir := "../../examples"

	// Get a list of all subdirectories in the examples directory
	exampleSubDirs, err := files.GetDirsInDir(examplesDir)
	if err != nil {
		t.Fatalf("Failed to get subdirectories of %s: %v", examplesDir, err)
	}

	// Loop through each example subdirectory and run tests
	for _, exampleSubDir := range exampleSubDirs {
		// Construct the full path to the example
		exampleFullPath := filepath.Join(examplesDir, exampleSubDir)

		// Define a test name
		testName := fmt.Sprintf("Example %s", exampleSubDir)

		// Run the test
		t.Run(testName, func(t *testing.T) {
			testExample(t, exampleFullPath)
		})
	}
}

func testExample(t *testing.T, exampleDir string) {
	t.Parallel()

	// Configure Terraform settings
	terraformOptions := &terraform.Options{
		TerraformDir: exampleDir,
	}

	//defer terraform.Destroy(t, terraformOptions) // Commented to avoid destroying resources

	// Initialize and apply
	_, err := terraform.InitAndApplyE(t, terraformOptions)
	if err != nil {
		t.Fatalf("Failed to apply Terraform: %v", err)
	}

	// Get the project ID from terraform.tfvars
	projectID, err := getProjectIDFromTFVars(exampleDir)
	if err != nil {
		t.Fatalf("Failed to get project ID from terraform.tfvars: %v", err)
	}

	// Check if the Network name is correct
	networkName := terraform.Output(t, terraformOptions, "network_name")
	assert.NotEmpty(t, networkName, "Network name should not be empty")

	// Check if the network self link contains the project id
	networkSelfLink := terraform.Output(t, terraformOptions, "network_self_link")
	assert.Contains(t, networkSelfLink, projectID, "Network self link should contain project ID")

}

func getProjectIDFromTFVars(exampleDir string) (string, error) {
	tfvarsPath := filepath.Join(exampleDir, "terraform.tfvars")

	// Check if terraform.tfvars exists
	if _, err := os.Stat(tfvarsPath); os.IsNotExist(err) {
		return "", fmt.Errorf("terraform.tfvars not found in %s", exampleDir)
	}

	// Read the file content
	content, err := os.ReadFile(tfvarsPath)
	if err != nil {
		return "", fmt.Errorf("failed to read terraform.tfvars: %v", err)
	}

	// Split the content into lines and search for project_id
	lines := strings.Split(string(content), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "project_id") {
			parts := strings.Split(line, "=")
			if len(parts) == 2 {
				projectID := strings.TrimSpace(strings.Trim(parts[1], "\""))
				return projectID, nil
			}
		}
	}

	return "", fmt.Errorf("project_id not found in terraform.tfvars")
}