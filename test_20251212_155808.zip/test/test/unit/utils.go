package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// AssertStringValueEquals asserts that a string value from terraform output equals the expected value.
func AssertStringValueEquals(t *testing.T, terraformOptions *terraform.Options, outputName string, expectedValue string) {
	actualValue := terraform.Output(t, terraformOptions, outputName)
	assert.Equal(t, expectedValue, actualValue, "Output %s should match expected value", outputName)
}