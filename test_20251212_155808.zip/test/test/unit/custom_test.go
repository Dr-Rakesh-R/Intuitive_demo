package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
)

func TestCustomExample(t *testing.T) {
	t.Parallel()

	terraformOptions := &terraform.Options{
		TerraformDir: "../../examples/custom",
	}

	// Clean up resources after tests.
	defer terraform.Destroy(t, terraformOptions)

	// Run "terraform init" and "terraform apply". Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	t.Run("NetworkName", func(t *testing.T) {
		expectedName := "my-custom-vpc"
		AssertStringValueEquals(t, terraformOptions, "network_name", expectedName)
	})

	t.Run("NetworkSelfLink", func(t *testing.T) {
		// Validation of self link would require mocking or a live GCP setup
		networkSelfLink := terraform.Output(t, terraformOptions, "network_self_link")
		if networkSelfLink == "" {
			t.Errorf("Network Self Link is empty")
		}
	})
}