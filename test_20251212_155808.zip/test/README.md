# Test Network Module

This module creates a Google Cloud VPC network.

## Usage

module "test_network" {
  source            = "./modules/test"
  network_name      = "my-custom-network"
  project_id = "my-gcp-project-id"
  auto_create_subnetworks = false

  routing_config = {
    routing_mode = "GLOBAL"
  }
}

## Inputs

| Name                     | Description                                      | Type   | Default | Required |
| ------------------------ | ------------------------------------------------ | ------ | ------- | :------: |
| `network_name`           | The name of the network.                         | string | `"test-network"` |    no   |
| `auto_create_subnetworks` | Whether to create subnetworks automatically.     | bool   | `false` |    no   |
| `project_id`            | The ID of the project.                           | string |         |   yes    |
| `routing_config`        | The routing configuration for the network.       | object | `null`  |    no   |

## Outputs

| Name              | Description                   |
| ----------------- | ----------------------------- |
| `network_name`      | The name of the network.      |
| `network_self_link` | The self-link of the network. |