package e2e

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestExamples(t *testing.T) {
	exampleDir := filepath.Join("..", "examples")

	// Find all subdirectories under the examples directory
	exampleSubdirs, err := files.GetDirsInDir(exampleDir, true)
	assert.NoError(t, err)

	for _, exampleSubdir := range exampleSubdirs {
		// Create a descriptive name for the test
		testName := strings.ReplaceAll(exampleSubdir, exampleDir+"/", "")
		testName = strings.ReplaceAll(testName, "/", "_")

		t.Run(testName, func(t *testing.T) {
			// Set up Terraform options
			terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
				TerraformDir: exampleSubdir,
				Vars: map[string]interface{}{
					"project_id": "gcp-project-id", // Override project_id for testing
				},
			})

			// Initialize and apply the example
			terraform.InitAndApply(t, terraformOptions)

			// Check if outputs exist
			_, err := os.Stat(filepath.Join(exampleSubdir, "outputs.tf"))
			if err == nil {
				// Get Outputs and check if they are not empty
				bucketID := terraform.Output(t, terraformOptions, "bucket_name")
				assert.NotEmpty(t, bucketID, "bucket_name output should not be empty")
				bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
				assert.NotEmpty(t, bucketURL, "bucket_url output should not be empty")
			} else {
				fmt.Println("No outputs.tf found")
			}

			// Destroy the example infrastructure
			defer terraform.Destroy(t, terraformOptions)
		})
	}
}