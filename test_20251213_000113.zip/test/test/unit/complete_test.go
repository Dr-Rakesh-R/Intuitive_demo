package complete

import (
	"github.com/gruntwork-io/terratest/modules/terraform"
	test "test/unit"
	"testing"
)

func TestCompleteExample(t *testing.T) {
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../examples/complete",
		Vars: map[string]interface{}{
			"project_id": "gcp-project-id",
		},
	})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	t.Run("BucketName", func(t *testing.T) {
		test.AssertTerraformOutputEquals(t, terraformOptions, "bucket_name", "complete-bucket")
	})

	t.Run("BucketURLNotEmpty", func(t *testing.T) {
		bucketURL := terraform.Output(t, terraformOptions, "bucket_url")
		test.AssertNotEmpty(t, bucketURL)
	})
}