# Terraform Google Cloud Project Module

This module creates a Google Cloud Project.

## Usage

module "project" {
  source = "./modules/project"

  project_name    = "My Project"
  project_id      = "my-project-id"
  org_id          = "1234567890"
  billing_account = "000000-000000-000000"
}

## Inputs

| Name            | Description                                  | Type   | Default | Required |
|-----------------|----------------------------------------------|--------|---------|----------|
| project_name    | The display name of the project.            | string |         | yes      |
| project_id      | The unique ID of the project.               | string |         | yes      |
| org_id          | The organization ID to create the project in. | string |         | yes      |
| billing_account | The billing account ID.                     | string |         | yes      |

## Outputs

| Name           | Description             |
|----------------|-------------------------|
| project_id     | The project ID.         |
| project_number | The project number.     |