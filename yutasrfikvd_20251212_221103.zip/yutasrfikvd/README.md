# Terraform Google Cloud Network Module

This module creates a Google Cloud VPC network and associated firewall rules.  Optionally creates a subnetwork if `auto_create_subnetworks` is set to `false`.

## Usage

module "network" {
  source         = "./modules/yutasrfikvd" # Replace with the actual path to the module

  project_id             = "your-project-id"
  network_name           = "my-custom-network"
  auto_create_subnetworks = false
  region = "us-west1"
  subnet_ip_cidr_range = "10.0.0.0/24"
  private_ip_google_access = true
}

## Inputs

| Name                     | Description                                                                 | Type        | Default                | Required |
| ------------------------ | --------------------------------------------------------------------------- | ----------- | ---------------------- | :------: |
| `project_id`             | The ID of the project in which to create the network.                       | `string`    |                        |   Yes    |
| `network_name`           | The name of the network.                                                    | `string`    | `"default-network"`    |    No    |
| `auto_create_subnetworks` | Whether to create subnetworks automatically (true) or not (false).           | `bool`      | `true`                 |    No    |
| `gateway_ipv4`         | An optional gateway IPv4 address to assign to the network.                 | `object`  | `null`                  |    No    |
| `routing_config`       | The routing configuration for the network.                                   | `object`  | `null`                  |    No    |
| `firewall_target_tags` | A list of target tags to apply to the firewall rule.                      | `list(string)`| `["http-server", "https-server"]`|    No    |
| `region`                 | The region to create the subnetwork in (if auto_create_subnetworks is false). | `string`    | `"us-central1"`        |    No    |
| `subnet_ip_cidr_range`   | The IP CIDR range for the subnetwork (if auto_create_subnetworks is false).  | `string`    | `"10.10.0.0/24"`       |    No    |
| `private_ip_google_access`| Whether to enable private IP google access for the subnetwork (if auto_create_subnetworks is false). | `bool` | `false`| No |

## Outputs

| Name                 | Description                                  |
| -------------------- | -------------------------------------------- |
| `network_name`       | The name of the network.                     |
| `network_id`         | The ID of the network.                       |
| `network_self_link`  | The self_link of the network.                |
| `subnetwork_names`   | The names of the subnetworks created.        |
| `subnetwork_self_links`| The self_links of the subnetworks created. |