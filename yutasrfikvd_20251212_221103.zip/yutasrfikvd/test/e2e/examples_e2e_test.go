package e2e

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/require"
)

func TestExamples(t *testing.T) {
	examplesDir := "../../examples"

	exampleDirs, err := files.ListSubdirectories(examplesDir)
	require.NoError(t, err)

	for _, exampleDir := range exampleDirs {
		// Define test name
		testName := filepath.Base(exampleDir)
		t.Run(testName, func(t *testing.T) {
			t.Parallel()
			testExample(t, exampleDir)
		})
	}
}

func testExample(t *testing.T, exampleDir string) {
	projectId := os.Getenv("GOOGLE_CLOUD_PROJECT")
	require.NotEmpty(t, projectId, "GOOGLE_CLOUD_PROJECT must be set")

	terraformOptions := &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": projectId,
		},
	}

	defer terraform.Destroy(t, terraformOptions)

	// Check if terraform.tfvars exist and has project_id, if not add it
	tfvarsFile := filepath.Join(exampleDir, "terraform.tfvars")
	if files.FileExists(tfvarsFile) {
		content, err := os.ReadFile(tfvarsFile)
		require.NoError(t, err)

		fileContent := string(content)
		if !strings.Contains(fileContent, "project_id") {
			err := os.WriteFile(tfvarsFile, []byte(fmt.Sprintf("project_id = \"%s\"\n%s", projectId, fileContent)), 0644)
			require.NoError(t, err)

			// Reinitialize terraform options due to changes in tfvars file
			terraformOptions = &terraform.Options{
				TerraformDir: exampleDir,
				Vars: map[string]interface{}{
					"project_id": projectId,
				},
			}
		}
	}

	_, err = terraform.InitAndApplyE(t, terraformOptions)
	require.NoError(t, err)
}