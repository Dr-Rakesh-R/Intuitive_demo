package test

import (
	"fmt"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// AssertNetworkName asserts that the network name output matches the expected value.
func AssertNetworkName(t *testing.T, terraformOptions *terraform.Options, expectedName string) {
	actualName := terraform.Output(t, terraformOptions, "network_name")
	assert.Equal(t, expectedName, actualName, "Network name should match")
}

// AssertApplySucceeds asserts that terraform apply succeeds.
func AssertApplySucceeds(t *testing.T, terraformOptions *terraform.Options) {
	_, err := terraform.ApplyAndIdempotentE(t, terraformOptions)
	assert.NoError(t, err, "Terraform apply should succeed")
}

// GetTerraformOptions returns Terraform options with the given example directory and project ID.
func GetTerraformOptions(t *testing.T, exampleDir string, projectId string) *terraform.Options {
	return &terraform.Options{
		TerraformDir: exampleDir,
		Vars: map[string]interface{}{
			"project_id": projectId,
		},
	}
}

func AssertSubnetCount(t *testing.T, terraformOptions *terraform.Options, expectedCount int) {
	subnetNames, err := terraform.OutputListE(t, terraformOptions, "subnetwork_names")

	if err != nil {
		if expectedCount == 0 && fmt.Sprintf("%s", err) == "output subnetwork_names not found" {
			return
		}
		t.Fatal(err)
	}

	assert.Equal(t, expectedCount, len(subnetNames), "Subnetwork count should match")
}