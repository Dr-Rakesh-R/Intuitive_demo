package simple

import (
	"os"
	"testing"

	test "test/unit"

	"github.com/gruntwork-io/terratest/modules/terraform"
)

func TestSimpleNetwork(t *testing.T) {
	t.Parallel()

	projectId := os.Getenv("GOOGLE_CLOUD_PROJECT")
	if projectId == "" {
		t.Fatal("GOOGLE_CLOUD_PROJECT environment variable must be set")
	}

	terraformOptions := test.GetTerraformOptions(t, "../../examples/simple", projectId)

	defer terraform.Destroy(t, terraformOptions)

	t.Run("ApplySucceeds", func(t *testing.T) {
		test.AssertApplySucceeds(t, terraformOptions)
	})

	t.Run("ValidateNetworkName", func(t *testing.T) {
		test.AssertNetworkName(t, terraformOptions, "simple-network")
	})

	t.Run("ValidateSubnetCount", func(t *testing.T) {
		test.AssertSubnetCount(t, terraformOptions, 0)
	})
}